package com.ncist.class6.MobilePhone;

public class Test {
    public static void main(String[] args) {
        MobilePhone phone = new MobilePhone("HUAWEIMate30","16945678999",3380);
        phone.display();
    }
}
